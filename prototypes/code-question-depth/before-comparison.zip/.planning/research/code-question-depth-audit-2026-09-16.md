# Code-question depth audit

**Status:** bounded research and prototype recommendation, 2026-09-16.

**User direction:** consider useful levels for content-specific questions,
identify what is optimal and beneficial, and perform the same kind of audit for
code questions.

## Finding

Code questions currently have two strong endpoints but an under-specified
middle. The shared quiz surface safely renders ordinary stems as text. Check
items can provide a real editor and runtime-owned deterministic checks. The CS
Dojo prototype goes further with prediction, editing, bounded browser execution,
feedback, retry and export. A code-reading question should not need a fake IDE
to gain preserved indentation, visible control flow, or a useful variable
trace.

The missing contract is a task-sized depth choice. Depth is not quality,
difficulty, mastery, hint tier, or score. Each item should use the lowest depth
that makes its intended thinking legible and lets the learner diagnose the
kind of error the objective cares about.

## Depth model

| Depth | Learner experience | Best fit | Required floor | Main cost or risk |
|---|---|---|---|---|
| D0 faithful | exact source with language, whitespace, indentation and line breaks preserved | terminology, recognition and questions where code is only evidence | selectable plain code with an explicit language and linear reading order | flattened or malformed syntax changes the problem |
| D1 orient | D0 plus line numbers, restrained syntax roles, task label and declared context | identify, locate, compare and explain questions | non-color labels and the same source without highlighting | decoration can imply importance or an answer |
| D2 unpack | D1 plus learner-controlled state, call, stack, heap or data-flow views | output prediction, tracing and misconception diagnosis | a text state table or ordered trace that does not auto-reveal the result | the visualization can replace prediction with watching |
| D3 manipulate | D2 plus ordering, marking, small edits, test cases or comparing runs | debugging, completion and local repair | keyboard-equivalent controls, deterministic validation and retained draft | interaction can drift from the tested construct |
| D4 construct | a real editor or artifact workspace with declared runtime, tests, explanation and transfer | functions, algorithms, multi-step programming and authentic production | useful static brief, explicit execution limits, recovery and export | hostile code, packages, persistence and multi-file state become product obligations |

These depths are composable, not a forced sequence. A debugging question may
use D1 and D3 without an animated trace. A concept question may remain at D0.
An exam-aligned output question may deliberately stop at D1 because a D2 trace
would remove the construct being measured.

## Code-question family audit

| Question family | Default depth | Useful enhancement | Avoid |
|---|---:|---|---|
| concept or terminology choice | D0 to D1 | mark the named expression or compare two short snippets | an editor that adds no learning action |
| output prediction and code reading | D1 to D2 | require a prediction, then let the learner fill or step through a state table | revealing the next value before the learner commits |
| trace or state reconstruction | D2 to D3 | editable variable rows, call frames or ordered events with deterministic checks | decorative animation without a linear equivalent |
| debugging and fault location | D2 to D3 | show the symptom, let the learner mark a line, explain the cause, then make a bounded repair | treating a passing example as proof of correctness |
| completion or small function | D3 to D4 | real editor, declared examples, hidden checks only when assessment rules permit, retry and controlled reveal | client-side scoring or undeclared packages and files |
| algorithm or design explanation | D1 to D4 | pseudocode, diagram, tradeoff table and an optional runnable probe | auto-grading prose or equating execution with explanation |
| multi-file, package or security task | D4, deferred | durable project state, isolated runner, manifest, restore and explicit capabilities | production use before hostile-code and recovery gates pass |

## Optimality and benefit test

A richer depth is beneficial only when it improves the target learner action.
Acceptable evidence includes better transfer to a new example, more accurate
state prediction, faster diagnosis of a relevant misconception, fewer syntax
reading errors, or clearer explanation without answer leakage. Time-on-screen,
novelty and engagement alone are not enough.

Compare every candidate with the next simpler depth. Reject or revise it when
it adds navigation, visual noise or tool learning without improving the target
action. Also reject it when it weakens exam fidelity, exposes restricted
feedback, changes the source, loses a draft, or makes the accessible fallback a
different task.

## Progressive assistance

Runtime-issued hints may add a teaching layer to any depth, but the client must
not infer the next line, variable or bug from keyed content. Safe additions
include an authored term definition, an already-disclosed invariant, a prompt
to inspect a named line, or a blank state table tied to the visible source.
Answer-bearing traces, failing hidden cases and repairs remain locked until the
runtime explicitly releases them.

The level choice and hint ladder stay independent. Opening a hint does not
silently turn D1 into D2. If assistance introduces a trace or editor, the page
labels that transition and preserves the untouched source and the learner's
prior response.

## First bounded prototype

Use one original synthetic output-prediction item with a short loop or function.
Compare:

1. D1, a dedicated read-only code panel with language, preserved indentation,
   line numbers and a prediction field.
2. D2, the same source and prediction field plus a learner-filled state table
   that can be checked only after the prediction is committed.

Measure prediction accuracy, ability to explain the first mistaken state,
completion time, navigation burden and narrow-width readability. The D2 version
earns promotion only if it improves state reasoning or error diagnosis without
giving away the output. A debugging D3 comparison comes next only if the D2
result identifies a real need for manipulation. Do not begin with another full
editor.

## Authority, safety and recovery gates

- The bank and accepted artifact retain exact code and declared language. Rich
  views are derived and disposable.
- The runtime remains the only scorer, hint-disclosure authority and evidence
  writer. Prose remains pending or explicitly advisory.
- Representative fixtures cover parsing or compilation when intended, syntax
  and indentation, keyboard and touch, screen-reader order, zoom and reflow,
  contrast themes, reduced motion and a useful no-script representation.
- Execution has no undeclared network, host filesystem or package access. It
  needs deterministic time and output limits, cancellation, isolation and an
  unavailable-capability fallback.
- Editing preserves drafts across hints, retries, navigation and interruption.
  Accepted multi-file work requires a manifest, atomic writes, export and a
  clean restore before production promotion.

## Routing

IL-20260912-02 owns thematic question presentation and the D0 through D2
comparison. IL-20260906-09 owns executable D3 and D4 capability through the CS
Dojo route. The existing runtime hint ladder owns disclosure. This audit adds
selection criteria and a promotion gate. It does not accept a new schema,
renderer, runner, scoring path or course format.

## Prototype disposition, 2026-09-18

The first bounded comparison now exists at
`prototypes/code-question-depth/`. The rendered D1 view preserves indentation,
line numbers, language context, and a prediction field. Committing a prediction
reveals a learner-filled D2 state table. The check names only the first
inconsistent row. It does not execute code, score an item, write evidence, or
reveal a result. Its Node gate passes and localhost rendering confirmed the
prediction-first transition. Promotion still requires the human comparison
metrics and accessibility observations named above.
