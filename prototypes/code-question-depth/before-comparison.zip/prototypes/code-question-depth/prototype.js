export const expectedTrace = [1, 3, 6];

export function checkTrace(values) {
  const normalized = values.map(value => Number(String(value).trim()));
  const firstMismatch = normalized.findIndex((value, index) => value !== expectedTrace[index]);
  return firstMismatch < 0
    ? {ok: true, message: "Your three recorded states are internally consistent."}
    : {ok: false, message: `Recheck the row for n = ${firstMismatch + 1}.`};
}

if (typeof document !== "undefined") {
  const prediction = document.querySelector("#prediction");
  const commit = document.querySelector("#commit");
  const trace = document.querySelector("#trace");
  const status = document.querySelector("#status");
  commit.addEventListener("click", () => {
    if (!prediction.value.trim()) { status.textContent = "Enter a prediction first."; return; }
    prediction.readOnly = true;
    trace.hidden = false;
    trace.querySelector("input").focus();
  });
  document.querySelector("#check").addEventListener("click", () => {
    const result = checkTrace(Array.from(trace.querySelectorAll("input"), input => input.value));
    status.textContent = result.message;
  });
}
