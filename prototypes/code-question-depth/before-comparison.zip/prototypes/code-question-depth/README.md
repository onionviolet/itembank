# Code question D1/D2 comparison

Status: disposable prototype, not an accepted item type or scoring path.

This compares the same output-prediction task at D1 and D2. D1 preserves code, indentation, line numbers, language context, and the prediction action. D2 appears only after a prediction and asks the learner to fill a text-equivalent state table. The browser check diagnoses the first inconsistent row. It does not score the assessment, execute code, reveal hidden cases, write evidence, or call a network service.

Gate: `node prototypes/code-question-depth/verify.mjs`. Human comparison still needs narrow-screen, keyboard, touch, screen-reader, completion-time, and explanation-quality observation. Delete this directory to roll it back.
