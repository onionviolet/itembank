import assert from "node:assert/strict";
import {checkTrace, expectedTrace} from "./prototype.js";
assert.deepEqual(expectedTrace, [1, 3, 6]);
assert.equal(checkTrace([1, 3, 6]).ok, true);
assert.deepEqual(checkTrace([1, 4, 7]), {ok:false, message:"Recheck the row for n = 2."});
const source = await (await import("node:fs/promises")).readFile(new URL("index.html", import.meta.url), "utf8");
for (const token of ["Commit prediction", "Text trace fallback", "aria-label=\"Python source\"", "role=\"status\""]) assert.ok(source.includes(token), token);
console.log("ok: D1/D2 prototype keeps prediction first, trace learner-filled, and a no-script fallback");
